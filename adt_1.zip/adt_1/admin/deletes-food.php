<?php 

  include('../config/constants.php');

//echo "delete food page";

if(isset($_GET['id']) && isset($_GET['image_name']))
{

    //echo "process to delete";

    $id = $_GET['id'];
    $image_name = $_GET['image_name'];

    if($image_name != "")
    {
           $path = "../images/food/".$image_name;

           $remove = unlink($path);

           if($remove==false)
           {

            $_SESSION['upload'] = "<div class='error'>Failed To Remove Image File.</div>";

            header('location:'.SITEURL.'admin/manage-food.php');

            die();
           }
    }


     $sql = "DELETE FROM foodmenu_table WHERE id=$id";
     $res = mysqli_query($conn, $sql);

     if($res==true)
     {
         $_SESSION['delete'] = "<div class='success'>Food Deleted successfully.</div>";
         header('location:'.SITEURL.'admin/manage-food.php');

     }
     else
     {

        $_SESSION['delete'] = "<div class='success'>failed to delete food.</div>";
        header('location:'.SITEURL.'admin/manage-food.php');


     }


}
else
{
   //echo "redirect page";

   $_SESSION['unauthorize'] = "<div class='error'>Unauthorized Access.</div>";
   header('location:'.SITEURL.'admin/manage-food.php');
}

?>