<?php include('partials/menu.php'); ?>

<div class="main-content">
     <div class="wrapper">
        <h1>update admin</h1>

        <br><br>

        <?php

        $id=$_GET['id'];

        $sql="SELECT * FROM admin_table WHERE id=$id";

        $res=mysqli_query($conn, $sql);

        if($res==true)
        {

            $count = mysqli_num_rows($res);

            if($count==1)
            {
             // echo "Admin Available";
             $row=mysqli_fetch_assoc($res);

             $fullname = $row['fullname'];
             $username = $row['username'];
            }
            else
            {
               header('location:'.SITEURL.'admin/manage-admin.php'); 
            }
        }
        
        
        ?>

        <form action="" method="POST">
         
        <table class="tbl30">
            <tr>
                <td>fullname: </td>
                <td>
                    <input type="text" name="fullname" value="<?php  echo $fullname;?>">
                </td>
            </tr>
            
            <tr>
                <td>username: </td>
                <td>
                    <input type="text" name="username" value="<?php echo $username; ?>">


                </td>
            </tr>

            <tr>
                <td colspan="2">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">

                    <input type="submit" name="submit" value="update Admin" class="btn-secondary">
                </td>
            </tr>


        </table>
        </form> 
     </div>
</div>

<?php

if(isset($_POST['submit']))
{
   // echo " button clicked ";
    $id = $_POST['id'];
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];

    $sql = "UPDATE admin_table SET
    fullname = '$fullname',
    username = '$username'
    WHERE id = '$id'
    ";
  
     $res = mysqli_query($conn, $sql);

     if($res==true)
     {
        $_SESSION['update']="<div class='success'>Admin updated successfully.</div> ";

        header('location:'.SITEURL.'admin/manage-admin.php');
     }
     else
     {
        $_SESSION['update']="<div class='error'>Failed to delete admin.</div> ";

        header('location:'.SITEURL.'admin/manage-admin.php');
     }
     
}
     
     
    

?>



<?php include('partials/footer.php'); ?>