<?php include('partials/menu.php');?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add Admin</h1>

        <br></br>

        <?php
        if(isset($_SESSION['add']))
        {
          echo $_SESSION['add'];
          unset($_SESSION['add']);
        }
        
        ?>

        <form action=""method="post">

        <table class="tbl30">
            <tr>
                <td>Fullname: </td>
                <td><input type="text" name="fullname" placeholder="Enter your Name" ></td>
            </tr>
           
           <tr>
            <td>Username: </td>
            
            <td><input type="text" name="username" placeholder="Enter your Name" ></td>
          </tr>

          <tr>
                <td>password: </td>
                
                <td><input type="password" name="password" placeholder="your password" ></td>

          </tr>
          <tr>
            <td colspan="2">
                <input type="submit" name="submit" value="Add Admin" class="btn-secondary">
            </td>



          </tr>
        </table>
        </form>

</div>
<?php include('partials/footer.php');?>

<?php 
     if(isset($_POST['submit']))
     {
       $fullname = $_POST['fullname'];
       $username = $_POST['username'];
       $password = md5($_POST['password']);

       $sql = "INSERT INTO admin_table SET
            fullname='$fullname',
            username='$username',
            password='$password'
       
       ";


      
       $res = mysqli_query($conn, $sql) or die(mysqli_error());
       

       if($res==TRUE)
       {
          //echo"data inserted";
          $_SESSION['add'] = "Admin Added successfully";

          header("location:".SITEURL.'admin/manage-admin.php');

       }
       else
       {

        //echo"data not inserted";

        
        $_SESSION['add'] = "Failed to Add Admin";

        header("location:".SITEURL.'admin/add-admin.php');
 

       }

     }




?>
