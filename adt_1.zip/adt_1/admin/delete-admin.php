<?php
 include('../config/constants.php');

 $id = $_GET['id'];

 $sql = "DELETE FROM admin_table WHERE id=$id";

 $res = mysqli_query($conn, $sql);

 if($res==true)
 {
   //echo "admin deleted";
   $_SESSION['delete'] ="<div class='success'>Admin Deleted Successfully";

   header('location:'.SITEURL.'admin/manage-admin.php');


 }
 else
 {
   //echo "failed to delete admin";
   $_SESSION['delete'] ="<div class='error'>Failed to Delete Admin.Try again later";

   header('location:'.SITEURL.'admin/manage-admin.php');

 }




?>