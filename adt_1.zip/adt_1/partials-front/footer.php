 <!-- social Section Starts Here -->
 <section class="social">
        <div class="container text-center">
           
        </div>
    </section>
    <!-- social Section Ends Here -->


    <!-- footer Section starts Here -->

    <section class="footer background-image">
        <div class="container.text-center bg-info">
            <h2>Minimum order of 10 persons</h2>
            <h1>contact number: 6385881076</h1>





            
</div>
</section>



    

</body>
</html>